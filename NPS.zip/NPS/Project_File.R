# Load necessary libraries
library(tidyverse)

# Load the dataset
file_path <- "NPS_Final_Dataset.csv"
dataset <- read_csv(file_path, guess_max = 10000)


# Data Cleaning Steps / EDA

# 1. Identify column types
numerical_cols <- dataset %>%
  select(where(is.numeric)) %>%
  names()

categorical_cols <- dataset %>%
  select(where(is.character)) %>%
  names()

logical_cols <- dataset %>%
  select(where(is.logical)) %>%
  names()

# 2. Handle missing values
# Replace missing values in numerical columns with the column mean
dataset <- dataset %>%
  mutate(across(all_of(numerical_cols), ~ if_else(is.na(.), mean(., na.rm = TRUE), .)))

# Replace missing values in categorical columns with "Unknown"
dataset <- dataset %>%
  mutate(across(all_of(categorical_cols), ~ if_else(is.na(.), "Unknown", .)))

# Replace missing values in logical columns with FALSE
dataset <- dataset %>%
  mutate(across(all_of(logical_cols), ~ if_else(is.na(.), FALSE, .)))


# 3. Drop the unwanted columns
# Specify columns to drop
columns_to_drop <- c(
  "visitor_center_id", 
  "visitor_center_name", 
  "visitor_center_amenities", 
  "visitor_center_standardHours", 
  "isParkingFeePossible", 
  "isParkingOrTransportationFeePossible", 
  "campground_id", 
  "campground_reservationInfo", 
  "campground_regulationsOverview", 
  "campground_fees", 
  "accessibility.wheelchairAccess", 
  "activity_id", 
  "Location", 
  "park_latitude", 
  "park_longitude", 
  "park_isMapPinHidden"
)

# Drop the specified columns
dataset <- dataset %>%
  select(-all_of(columns_to_drop))

# Preview the cleaned dataset
glimpse(dataset)

# 4. Exploring the Distribution of Park States and Park Designation
# Bar Chart: Distribution of park_states
ggplot(dataset, aes(x = factor(park_states))) +
  geom_bar() +
  labs(title = "Number of Parks by State", x = "State", y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))

# Bar Chart: Distribution of park_designation

ggplot(dataset, aes(y = factor(park_designation))) +
  geom_bar(fill = "#fc8d62") +
  labs(title = "Distribution of Park Designations", x = "Count", y = "Park Designation") +
  theme_minimal()


# 5. Data Wrangling and Feature Engineering

# 5.a. Preprocessing Categorical and Logical Variables

# One hot encoding of categorical columns
# Identify categorical columns
categorical_columns <- dataset %>%
  select(where(is.character)) %>%
  names()

# Convert all categorical columns to numerical (label encoding)
dataset <- dataset %>%
  mutate(across(all_of(categorical_columns), ~ as.numeric(factor(.))))

# One hot encoding for columns with logical datatype
# Identify logical columns
logical_columns <- dataset %>%
  select(where(is.logical)) %>%
  names()

# Convert all logical columns to numerical (TRUE = 1, FALSE = 0)
dataset <- dataset %>%
  mutate(across(all_of(logical_columns), ~ as.integer(.)))

# Preview the modified dataset
glimpse(dataset)


# 5.b. Converting the decimal values in columns to relevant integer value
# Remove decimal values by converting to integers
dataset <- dataset %>%
  mutate(
    numberOfCampSitesReservable = as.integer(numberOfCampSitesReservable),
    campsites.totalSites = as.integer(campsites.totalSites),
    campsites.tentOnly = as.integer(campsites.tentOnly)
  )

# Replace any decimal value with 1 in the accessibility.rvAllowed column
dataset <- dataset %>%
  mutate(
    accessibility.rvAllowed = if_else(accessibility.rvAllowed %% 1 != 0, 1, accessibility.rvAllowed)
  )

# Preview the modified dataset
glimpse(dataset)


# Visualization

# 1. Distribution of the Target Variable (park_isOpenToPublic)
dataset %>%
  ggplot(aes(x = park_isOpenToPublic)) +
  geom_bar(fill = "steelblue") +
  labs(title = "Distribution of park_isOpenToPublic",
       x = "Is Open to Public",
       y = "Count") +
  scale_x_continuous(breaks = c(0, 1), labels = c("Closed", "Open")) +
  theme_minimal()

# 2. Ammenities graph
# Select the specified amenities
selected_amenities <- c(
  "amenities.trashRecyclingCollection",
  "amenities.toilets",
  "amenities.cellPhoneReception",
  "amenities.amphitheater",
  "amenities.dumpStation",
  "amenities.campStore",
  "amenities.staffOrVolunteerHostOnsite",
  "amenities.potableWater",
  "amenities.iceAvailableForSale",
  "amenities.firewoodForSale",
  "amenities.foodStorageLockers"
)

# Summarize data for plotting
amenities_data <- dataset %>%
  select(all_of(selected_amenities)) %>%
  summarise(across(everything(), sum)) %>%
  pivot_longer(cols = everything(), names_to = "Amenity", values_to = "Count")

# Plot the bar chart
amenities_data %>%
  arrange(desc(Count)) %>%
  ggplot(aes(x = reorder(Amenity, Count), y = Count)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  labs(title = "Count of Selected Amenities Across All Parks",
       x = "Amenities", y = "Count") +
  theme_minimal()

# 3. Stacked Bar Plot: Distribution of park_isManagedByNps by park_isOpenToPublic

ggplot(dataset, aes(x = factor(park_isOpenToPublic), fill = factor(park_isManagedByNps))) +
  geom_bar(position = "stack") +
  labs(title = "Park Management and Open Status", x = "Park Open to Public", y = "Count") +
  scale_x_discrete(labels = c("Closed", "Open")) +
  scale_fill_manual(values = c("red", "green")) +
  theme_minimal() +
  theme(legend.title = element_blank())


### ML model training

# Using Deep Learning Model

# Load necessary library
library(h2o)

# Initialize H2O
h2o.init()

# Load dataset or convert to H2O Frame
# Replace this with actual data loading logic if dataset isn't already loaded in R
dataset <- as.h2o(dataset)  # Replace `dataset` with the data frame if available

# Specify target and features
target <- "park_isOpenToPublic"
predictors <- setdiff(names(dataset), target)

# Convert target variable to factor
dataset[, target] <- as.factor(dataset[, target])

# Split data into training, validation, and testing sets
splits <- h2o.splitFrame(dataset, ratios = c(0.7, 0.15), seed = 123)
train <- splits[[1]]
valid <- splits[[2]]
test <- splits[[3]]

# Train a Deep Learning model
deep_learning_model <- h2o.deeplearning(
  x = predictors,
  y = target,
  training_frame = train,
  validation_frame = valid,
  hidden = c(128, 64, 32),  # Number of neurons in hidden layers
  epochs = 50,
  activation = "RectifierWithDropout",
  input_dropout_ratio = 0.1,
  seed = 123,
  model_id = "deep_learning_model.h2o"
)

# Evaluate the model on the validation set
performance <- h2o.performance(deep_learning_model, valid = TRUE)
print(performance)

# Predict on the test set
predictions <- h2o.predict(deep_learning_model, test)
print(predictions)

# Save the H2O model
model_filepath <- h2o.saveModel(
  object = deep_learning_model,             
  path = getwd(),          
  force = TRUE             
)

# Print the model file path for reference
print(model_filepath)

# Load the H2O model from the saved file
loaded_model <- h2o.loadModel(model_filepath)

# Verify that the loaded model is the same
summary(loaded_model)

# Shutdown H2O
h2o.shutdown(prompt = FALSE)


## SHAP Values 

# Convert Deep Learning model to DALEX explainer
dl_explainer <- explain_h2o(
  model = deep_learning_model,
  data = as.data.frame(train[, predictors]),
  y = as.vector(as.data.frame(train[, target])$park_isOpenToPublic),
  label = "H2O Deep Learning"
)

# SHAP values for Deep Learning model
shap_values_dl <- predict_parts(
  explainer = dl_explainer,
  new_observation = sample_obs,
  type = "shap"
)

# Plot SHAP values for Deep Learning model
plot(shap_values_dl) +
  ggtitle("SHAP Values for a Sample Observation (Deep Learning)")

